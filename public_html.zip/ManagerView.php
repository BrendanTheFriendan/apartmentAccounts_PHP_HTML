<?php

session_start();
//echo $_SESSION["currentUser"];

?>

<!DOCTYPE html>
<html>
<head>
	<title> Manager Info Viewer </title>
</head>

<html>
	<body>
		<a href = 'ManagerInfo.php'>View Manager Info</a></br>
		<a href = 'ManagerDashboard.php'>Back</a></br>
	</body>
</html>
