<?php

session_start();
//echo $_SESSION["currentUser"];

?>

<!DOCTYPE html>
<html>
<head>
	<title> Tenant Info Viewer </title>
</head>

<html>
	<body>
		<a href = 'TenantInfo.php'>View Tenant Info</a></br>
		<a href = 'TenantDashboard.php'>Back</a></br>
	</body>
</html>
