<!DOCTYPE html>
<html>
<head>
	<title> Staff index </title>
</head>

<html>
	<body>
		<a href = 'StaffLogin.php'>Staff Login</a></br>
		<a href = 'AddStaff.php'>Staff Signup</a></br>
	</body>
</html>
