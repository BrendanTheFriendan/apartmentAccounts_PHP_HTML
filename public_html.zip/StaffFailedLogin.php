<!DOCTYPE html>
<html>
<head>
	<title> Login Failed </title>
</head>

<html>
	<body>
		<a href = 'StaffLogin.php'>Try again</a></br>
		<a href = 'index.php'>Home</a></br>
	</body>
</html>
