<!DOCTYPE html>
<html>
<head>
	<title> Welcome Staff! </title>
</head>

<html>
	<body>
		<a href = 'StaffView.php'>View Your Info</a></br>
		<a href = 'StaffEdit.php'>Edit Your Account Info</a></br>
		<a href = 'PropertyInfo.php'>Update Properties</a></br>
		<a href = 'index.php'>Logout</a></br>
	</body>
</html>
