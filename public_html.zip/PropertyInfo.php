<!DOCTYPE html>
<html>
<head>
	<title> Edit Properties! </title>
</head>

<html>
	<body>
		<a href = 'EditProperty.php'>Edit Properties</a></br>
		<a href = 'EditUnit.php'>Edit Property Units</a></br>
		<a href = 'EditOffice.php'>Edit Office</a></br>
		<a href = 'StaffDashboard.php'>Return to Staff Dashboard</a></br>
	</body>
</html>
