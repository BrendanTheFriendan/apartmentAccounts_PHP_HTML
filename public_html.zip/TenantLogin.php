

<!DOCTYPE html>

<html>
	<head>
		<title>Tenant Login </title>
	</head>
	
	<body>
		<form action = "TenantCheckCredentials.php" method = "POST">
			<b> Tenant Login </b>
			<p> UserName : <input type="text" name="username" value=""/>
			</p>
			<p> Password : <input type="text" name="password" value=""/>
			</p>
			<p> <input type="submit" name="submit" value="Submit"/>
			</p>
		</form>
	</body>
</html>
