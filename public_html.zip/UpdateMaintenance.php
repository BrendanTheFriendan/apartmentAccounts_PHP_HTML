<?php

session_start();
//echo $_SESSION["currentUser"];

?>


<!DOCTYPE html>
<html>
<head>
	<title> Edit Maintenance Requests </title>
</head>

<html>
	<body>
		<a href = 'MaintenanceView.php'>View Maintenance Requests</a></br>
		<a href = 'ManagerDashboard.php'>Back</a></br>
	</body>
</html>
