<!DOCTYPE html>
<html>
<head>
	<title> Welcome Tenant! </title>
</head>

<html>
	<body>
		<a href = 'TenantLogin.php'>Login</a></br>
		<a href = 'AddTenant.php'>Signup</a></br>
	</body>
</html>
