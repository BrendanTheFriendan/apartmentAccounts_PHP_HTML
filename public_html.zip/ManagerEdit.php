<?php

session_start();

?>


<!DOCTYPE html>
<html>
<head>
	<title> Edit Info! </title>
</head>

<html>
	<body>
		<a href = 'EditManagerEmail.php'>EditEmail</a></br>
		<a href = 'EditManagerPhone.php'>Edit Phone</a></br>
		<a href = 'EditManagerPassword.php'>Reset Password</a></br>
		<a href = 'ManagerDashboard.php'>back</a></br>
	</body>
</html>
