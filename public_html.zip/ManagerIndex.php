<!DOCTYPE html>
<html>
<head>
	<title> Manager index </title>
</head>

<html>
	<body>
		<a href = 'ManagerLogin.php'>Manager Login</a></br>
		<a href = 'AddManager.php'>Manager Signup</a></br>
	</body>
</html>
