<?php

session_start();

?>


<!DOCTYPE html>
<html>
<head>
	<title> Edit Info! </title>
</head>

<html>
	<body>
		<a href = 'EditTenantEmail.php'>EditEmail</a></br>
		<a href = 'EditTenantPhone.php'>Edit Phone</a></br>
		<a href = 'EditTenantPassword.php'>Change Password</a></br>
		<a href = 'TenantDashboard.php'>back</a></br>
	</body>
</html>
