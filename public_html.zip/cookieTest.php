<?php

session_start();
$var_value = $_COOKIE['username'];
echo $var_value;
echo "!"
?>
