<!DOCTYPE html>

<html>
	<head>
		<title>Manager Login </title>
	</head>
	
	<body>
		<form action = "ManagerCheckCredentials.php" method = "POST">
			<b> Manager Login </b>
			<p> UserName : <input type="text" name="username" value=""/>
			</p>
			<p> Password : <input type="text" name="password" value=""/>
			</p>
			<p> <input type="submit" name="submit" value="Submit"/>
			</p>
		</form>
	</body>
</html>
