<!DOCTYPE html>
<html>
<head>
	<title> index </title>
</head>

<html>
	<body>
		<a href = 'TenantIndex.php'>TenantsHere</a></br>
		<a href = 'StaffIndex.php'>StaffHere</a></br>
		<a href = 'ManagerIndex.php'>ManagersHere</a></br>
	</body>
</html>
