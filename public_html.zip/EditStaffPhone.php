<!DOCTYPE html>

<html>
	<head>
		<title>Update Phone Number </title>
	</head>
	
	<body>
		<form action = "UpdateStaffPhone.php" method = "POST">
			<b> New Phone Number </b>
			<p> Phone Number : <input type="text" name="phone" value=""/>
			</p>
			<p> <input type="submit" name="submit" value="Submit"/>
			</p>
		</form>
	</body>
</html>
