<!DOCTYPE html>

<html>
	<head>
		<title>Staff Login </title>
	</head>
	
	<body>
		<form action = "StaffCheckCredentials.php" method = "POST">
			<b> Staff Login </b>
			<p> UserName : <input type="text" name="username" value=""/>
			</p>
			<p> Password : <input type="text" name="password" value=""/>
			</p>
			<p> <input type="submit" name="submit" value="Submit"/>
			</p>
		</form>
	</body>
</html>
