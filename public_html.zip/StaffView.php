<?php

session_start();
//echo $_SESSION["currentUser"];

?>

<!DOCTYPE html>
<html>
<head>
	<title> Staff Info Viewer </title>
</head>

<html>
	<body>
		<a href = 'StaffInfo.php'>View Staff Info</a></br>
		<a href = 'StaffDashboard.php'>Back</a></br>
	</body>
</html>
