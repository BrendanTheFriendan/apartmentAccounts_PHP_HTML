<?php
$cow='tt';
$_COOKIE
$var_value = $_SESSION['username'];

?>


