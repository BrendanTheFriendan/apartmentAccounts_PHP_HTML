<?php

session_start();

?>


<!DOCTYPE html>
<html>
<head>
	<title> Edit Info! </title>
</head>

<html>
	<body>
		<a href = 'EditStaffEmail.php'>Edit Email</a></br>
		<a href = 'EditStaffPhone.php'>Edit Phone</a></br>
		<a href = 'EditStaffPassword.php'>Reset Password</a></br>
		<a href = 'StaffDashboard.php'>back</a></br>
	</body>
</html>
