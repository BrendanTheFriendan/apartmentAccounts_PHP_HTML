<!DOCTYPE html>

<html>
	<head>
		<title>Update Email </title>
	</head>
	
	<body>
		<form action = "UpdateStaffEmail.php" method = "POST">
			<b> New Email Address </b>
			<p> Email : <input type="text" name="email" value=""/>
			</p>
			<p> <input type="submit" name="submit" value="Submit"/>
			</p>
		</form>
	</body>
</html>
